#ifndef Enemy_h
#define Enemy_h

#include "Rect.h"
#include "TexRect.h"

class Enemy: public TexRect{
	float dx, dy, speed;
	
	public:
		Enemy();
		
		void idle();
		
		//Add to this later lines 15 - 16
		void keyUp(unsigned char key, float x, float y);	
        void keyDown(unsigned char key, float x, float y);
        
        
        float getSpeed() const;
};



#endif
