#pragma once

#include "Enemy.h"
#include <iostream>

Enemy::Enemy() : TexRect::TexRect("galagaBugL.png", -.125, .75, .25, .25), dx(0), dy(0), speed(.002){

}

void Enemy::idle(){
	x += dx;
    y += dy;

    //stops the enemy from leaving screen
    if(x < -1){
        x = -1;
    }
    
    if(x + w > 1){
        x = 1- w;
    }
    
    if(y > 1){
        y = 1;
    }
    
    if(y - h < -1){
        y = -1 + h;
    }
	
	
}

void Enemy::keyDown(unsigned char key, float x, float y) {
	
}

void Enemy::keyUp(unsigned char key, float x, float y) {
	
}

float Enemy::getSpeed() const{
		return speed;
}
