#pragma once

#include "Game.h"
#include <iostream>

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif


Game::Game(int w, int h) : windowW(w), windowH(h){
	
	bg = new TexRect("galaxy.png", -1, 1, 2, 2); //added background 

    ship = new Ship();

	enemy = new Enemy();
	
    //enemy = new Rect(.20,.75, .25,.25,1,1,1);
	
	//Added lines 22 - 26
	//bug = new TexRect("galagaBug.png", -.45, .75, .25, .25); //add to Enemy.cpp
    //enemy = bug; //remove this
    
    //GShip = new TexRect ("galagaBug.png", -.125,-.6, .25,.25);
    //ship = GShip;
    
    explosion = new Sprite("explosion.png", 5, 5, -.15, .75, .25, .25);

    bulletSpeed = .004;

    win = loss = false;
    
    EnemyVisible = true;			//Added lines 50 to 51
    explosionVisible = false;
}

void Game::draw(){
	
	bg -> draw(-0.1); //add background
    
    if(win){
        renderText("YOU WIN!", -.2, .2);
        explosion->draw(); //1:13
        
    }else{
		if(EnemyVisible){		//added if if statement lines 62,64,65,66
        enemy->draw();
	}if(explosionVisible){
		explosion->draw();
	}
       
    }

    if(loss){
        renderText("GAME OVER", -.2, .2);
        
        
    }else{
        ship->draw();
        
        for(TexRect* r : bullets){ //changed to TexRect* r
            r->draw();
        
        }
    }
}


void Game::keyDown(unsigned char key, float x, float y) {
    if(!loss){
        ship->keyDown(key,x,y);
        
        if(key == ' '){
            fire();
        }
    }
}

void Game::keyUp(unsigned char key, float x, float y){
    if(!loss)
        ship->keyUp(key,x,y);
}

void Game::idle(){
    
    //bg -> draw(); //draw background
    
    if(!loss){
        ship->idle();

        if(!win && checkCollision(*ship,*enemy, *enemy2)){
            loss = true;
            
            EnemyVisible = false;		//Added lines 108 to 110
            explosionVisible = true;			
            explosionTimer(2);
        }
  
        for(TexRect* r : bullets){	//TexRect* r
            //move bullet up
            r->setY(r->getY() + bulletSpeed);
            if(!win && checkCollision(*r,*enemy,*enemy2)){
                win = 1;
            }
        }
    }
    
}
void Game::explosionTimer(int id){ //Just added minute 21pm
	explosion -> draw();
	
	if(explosion->isDone()){
		explosionVisible = false;
	}
	//glutTimerFunc(17, explosionTimer, id);
	
}

void Game::fire(){
	// change to TexRect to implement bullet
    bullets.push_front(new TexRect("galagaBullet.png",ship->getX() + ship->getW()/2 - .03, ship->getY(), .05,.1));
}

void Game::renderText(std::string text, float x, float y){
    glColor3f(1, 1, 1);
    float offset = 0;
    for (int i = 0; i < text.length(); i++) {
        glRasterPos2f(x+offset, y-2*(float)glutBitmapHeight(GLUT_BITMAP_TIMES_ROMAN_24)/windowH);
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, text[i]);
        offset += (2*(float)glutBitmapWidth(GLUT_BITMAP_TIMES_ROMAN_24, text[i]) / windowW);
    }
}

bool Game::checkCollision(const Rect& one, const Rect& two, const Rect& three) const{
    
    return  (one.getX() < (two.getX() + two.getW()) && two.getX() < (one.getX() + one.getW())) &&
            (one.getY() > (two.getY() - two.getH()) && two.getY() > (one.getY() - one.getH()));

}
 
Game::~Game(){
    for(TexRect* r : bullets){
        delete r;
    }
    delete ship;
    delete enemy;
    delete explosion; //added
    
    std::cout << "Exiting..." << std::endl;
    
}
