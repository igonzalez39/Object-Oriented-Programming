#ifndef Game_h
#define Game_h

#include "Ship.h"
#include "Rect.h"
#include "TexRect.h"
#include "Sprite.h"
#include <string>
#include <deque>
#include "GlutApp.h"
#include "Enemy.h"

class Game{

	//TexRect* bug;	//removed 4:12pm
	
	TexRect* bg;
	
	//TexRect* GShip;		// 12/7 added lines 13-16

    Ship* ship;
    Enemy* enemy;
    
    Rect* enemy2;
    //Rect* enemy3;
    std::deque<TexRect*> bullets; //changed from Rect* to TexRect*
    
    float bulletSpeed;
    bool win, loss;
    int windowW, windowH;
    
	Sprite* explosion;	//need to add functionality for lines 32 - 34
	bool explosionVisible;	
	bool EnemyVisible;


    public:
        Game(int , int );

        void draw();

        void keyDown(unsigned char key, float x, float y);

        void keyUp(unsigned char key, float x, float y);

        void idle();

        void fire();
        
        //friend void timer (int id); //Add later if time
		void explosionTimer(int id);	// 12/7 added lines 41-42
        

        void renderText(std::string text, float x, float y);

        bool checkCollision(const Rect& one, const Rect& two, const Rect& three) const;

        ~Game();
};


#endif
