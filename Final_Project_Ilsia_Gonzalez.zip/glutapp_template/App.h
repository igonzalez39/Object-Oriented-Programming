#ifndef App_h
#define App_h

#include "GlutApp.h"
#include "Rect.h"
#include "Game.h"
#include "TexRect.h"
#include "Sprite.h"

class App: public GlutApp {
	
     Game* game;

public:
    
    App(int argc, char** argv, int width, int height, const char* title);
    
    void draw();
    
    void keyDown(unsigned char key, float x, float y);

    void keyUp(unsigned char key, float x, float y);

    bool goLeft, goRight;

    void idle();

    ~App();
    
};

#endif
