#ifndef Ship_h
#define Ship_h

#include "Rect.h"
#include "TexRect.h"  //added this at 1:14pm

class Ship: public TexRect{		//changed from Rect to TexRect to add pic 1:14pm
    float dx, dy, speed;

    public:
        Ship();

        void idle();

        void keyUp(unsigned char key, float x, float y);
        void keyDown(unsigned char key, float x, float y);
        float getSpeed() const;
};



#endif
