#include <iostream>
#include <cmath>

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif

int width = 640, height = 640;


float red = 0.0;
float green = 1.0;
float blue = 0.0;

float redCircle = 0.0;
float greenCircle = 0.0;
float blueCircle = 0.0;


//Circle0 creates the top of s
float radius = 0.2;

float xOffset = 0.0;

float yOffset = 0.0;


//Circle1 creates the bottom of s
float radius1 = 0.2;

float xOffset1 = 0.0;

float yOffset1 = -0.32;


//Circle3 creates the top curve of s
float radius3 = 0.15;

float xOffset3 = 0.14;

float yOffset3 = -0.01;


//Circle4 creates the bottom curve of s
float radius4 = 0.15;

float xOffset4 = -0.14;

float yOffset4 = -0.31;



//Circle2 creates the outside of a
float radius2 = 0.2;

float xOffset2 = 0.6;

float yOffset2 = -0.32;


//Circle5 creates the outside of a
float radius5 = 0.1;

float xOffset5 = 0.6;

float yOffset5 = -0.32;





//-------------------------------------------------------
// A function to draw the scene
//-------------------------------------------------------
void appDrawScene() {
	// Clear the screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set background color to black
	glClearColor(0.0, 0.0, 0.0, 1.0);

	// Set up the transformations stack
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    

    // Draw stuff here
    

	//This draws the dot on i
    glColor3f(0.0, 1.0, 0.0);
    
    glPointSize(8);

    glBegin(GL_POINTS);
    
    glVertex2f(0.3, 0.33);

    glEnd();
	//This is the end of creation for the dot of i


	


	//This creates the lines
    glColor3f(0.0, 1.0, 0.0);
    
    glLineWidth(5);

    glBegin(GL_LINES);
    
    glVertex2f(-0.8, 0.5);
    glVertex2f(-0.4, 0.5);

    glVertex2f(-0.6, 0.5);
    glVertex2f(-0.6, -0.5);
     
    glVertex2f(-0.8, -0.5);
    glVertex2f(-0.4, -0.5);

    glVertex2f(-0.3, 0.5);
    glVertex2f(-0.3, -0.5);

    glVertex2f(0.3, 0.2);
    glVertex2f(0.3, -0.5);

    glVertex2f(0.8, -0.12);
    glVertex2f(0.8, -0.52);

    
    glEnd();
	//This is the end of creation for lines





	
	//This creates the circle    
    glColor3f(red, green, blue);
        
    float theta = 0;
    
    float thetaInc = M_PI/100; 
    
    glBegin(GL_POLYGON);
    
    for (theta; theta < 2*M_PI; theta+=thetaInc) {
        glVertex3f(radius * cos(theta) + xOffset, radius * sin(theta) + yOffset, 0.9);
    }
    
    glEnd(); 
       //This is when the circle creation ends
    

	//This creates the circle1
    glColor3f(red, green, blue);
        
    float theta1 = 0;
    
    float thetaInc1 = M_PI/100; 
    
    glBegin(GL_POLYGON);
    
    for (theta1; theta1 < 2*M_PI; theta1+=thetaInc1) {
        glVertex3f(radius1 * cos(theta1) + xOffset1, radius1 * sin(theta1) + yOffset1, 0.9);
    }
    
    glEnd(); 
       //This is when the circle creation ends


	//This creates the circle2   
    glColor3f(red, green, blue);
        
    float theta2 = 0;
    
    float thetaInc2 = M_PI/100; 
    
    glBegin(GL_POLYGON);
    
    for (theta2; theta2 < 2*M_PI; theta2+=thetaInc2) {
        glVertex3f(radius2 * cos(theta2) + xOffset2, radius2 * sin(theta2) + yOffset2, 0.9);
    }
    
    glEnd(); 
       //This is when the circle creation ends


	//This creates the circle3   
    glColor3f(redCircle, greenCircle, blueCircle);
        
    float theta3 = 0;
    
    float thetaInc3 = M_PI/100; 
    
    glBegin(GL_POLYGON);
    
    for (theta3; theta3 < 2*M_PI; theta3+=thetaInc3) {
        glVertex3f(radius3 * cos(theta3) + xOffset3, radius3 * sin(theta3) + yOffset3, 0.9);
    }
    
    glEnd(); 
       //This is when the circle creation ends


	//This creates the circle4
    glColor3f(redCircle, greenCircle, blueCircle);
        
    float theta4 = 0;
    
    float thetaInc4 = M_PI/100; 
    
    glBegin(GL_POLYGON);
    
    for (theta4; theta4 < 2*M_PI; theta4+=thetaInc4) {
        glVertex3f(radius4 * cos(theta4) + xOffset4, radius4 * sin(theta4) + yOffset4, 0.9);
    }
    
    glEnd(); 
       //This is when the circle creation ends


	//This creates the circle5   
    glColor3f(redCircle, greenCircle, blueCircle);
        
    float theta5 = 0;
    
    float thetaInc5 = M_PI/100; 
    
    glBegin(GL_POLYGON);
    
    for (theta5; theta5 < 2*M_PI; theta5+=thetaInc5) {
        glVertex3f(radius5 * cos(theta5) + xOffset5, radius5 * sin(theta5) + yOffset5, 0.9);
    }
    
    glEnd(); 
       //This is when the circle creation ends	







	// We have been drawing everything to the back buffer
	// Swap the buffers to see the result of what we drew
	glFlush();
	glutSwapBuffers();
}




int main(int argc, char** argv) {

	// Initialize GLUT
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH);

	// Setup window position, size, and title
	glutInitWindowPosition(20, 60);
	glutInitWindowSize(width, height);
	glutCreateWindow("CSE165 Lab1");

	//glMatrixMode(GL_PROJECTION);
	//glLoadIdentity();
	//glOrtho(0,640,640,0,-1,1);	
	



	// Set callback for drawing the scene
	glutDisplayFunc(appDrawScene);

	// Start the main loop
	glutMainLoop();


}







