#include "Rect.h"
#include <deque>
#include "Button.h"

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif


using namespace std;

button::button(){

    


    // b.push_front(new Rect(.8, .8, .1, .1, 1, 0, 0));
    // b.push_front(new Rect(.8, .6, .1, .1, 0, 1, 0));
    // b.push_front(new Rect(.8, .4, .1, .1, 0, 0, 1));
    // b.push_front(new Rect(.8, .2, .1, .1, 1, 0, 0));
    // b.push_front(new Rect(.8, 0.0, .1, .1, 1, 0, 0));


}


void Button::run(){
    //get selection algo from lab 2

}

void Button::changeColor(){
    //changed color of draw when box is clicked 


}