#ifndef BUTTON_H
#define BUTTON_H

#include "Rect.h"
#include <deque>

using namespace std;

struct button{


    deque<Rect*> b;


    bool buttonselect = false; //button selected 


    float x; 
    float y;
    float h;
    float w;


    void run(); //runs selectable squares
    void changeColor(); // controls color squares 
    void eraser(); //makes mouse an eraser 
    void paint(); //mouse draws 


};




#endif