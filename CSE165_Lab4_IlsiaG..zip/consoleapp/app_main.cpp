#include <iostream>
#include <ostream>

using namespace std;


struct Rect{
	float x;
	float y;
	float w;
	float h;

	int* num;

	// Constructor with default parameters and initializer list
	Rect(float x=0, float y=0, float w=1, float h=1): x(x), y(y), w(w), h(h) {
		num = new int(42);
	}
	// The constructor above is both a default constructor and a custom constructor
	// Every object we define *MUST* have a default constuctor

	// In addition, every object has to have a copy constructor

	Rect(const Rect& other){
		// cout << "Copy constructor called..." << endl;
		x = other.x;
		y = other.y;
		w = other.w;
		h = other.h;

		num = new int (*other.num);
	}

	~Rect(){
		delete num;
	}
};

bool operator ==(const Rect& one, const Rect& two){
	return one.h == two.h && one.w == two.w;
}

ostream& operator <<(ostream& os, const Rect& r){
	os << "(" << r.x << ", " << r.y << ", " << r.w << ", " << r.h << ") - " << *r.num;
	return os;
}


void f(Rect rectangle){
	rectangle.x = 99;
	*rectangle.num = 107;
	cout<< "The rectangle is: " << rectangle << endl;
}


int main(int argc, char** argv) {

	Rect r;
	Rect r2(10, 10, 1, 1);

	f(r);


	if (r == r2){
		cout << "Rects are the same" << endl;
	}
	else {
		cout << "Rects are not the same" << endl;
	}

	cout << r << endl;
	cout << r2 << endl;

	return 0;
}
