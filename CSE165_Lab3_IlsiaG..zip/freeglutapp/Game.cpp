#include "Game.h"
#include <iostream>

Game::Game(){
	playerOne = true;
	gameOver = false;

	board.push_back(new Rect(-0.8, 0.8, 0.5, 0.5));
	board.push_back(new Rect(-0.2, 0.8, 0.5, 0.5));
	board.push_back(new Rect(0.4, 0.8, 0.5, 0.5));

	board.push_back(new Rect(-0.8, 0.2, 0.5, 0.5));
	board.push_back(new Rect(-0.2, 0.2, 0.5, 0.5));
	board.push_back(new Rect(0.4, 0.2, 0.5, 0.5));

	board.push_back(new Rect(-0.8, -0.4, 0.5, 0.5));
	board.push_back(new Rect(-0.2, -0.4, 0.5, 0.5));
	board.push_back(new Rect(0.4, -0.4, 0.5, 0.5));
}


void Game::draw(){
	for (int i = 0; i < board.size(); i++){
		board[i]->draw();
	}
}

void Game::handle(float mx, float my){
	if (!gameOver){
		for (std::vector<Rect*>::iterator i = board.begin(); i != board.end(); ++i){
			if ((*i)->contains(mx, my)){
				if (!((*i)->xShape || (*i)->circleShape)){
				   // !((*i)->xShape) && !((*i)->circleShape)
					std::cout << "Clicked" << std::endl;

					if (playerOne){
						(*i)->playX();
						playerOne = false;

						// Check to see if player 1 won
					}
					else{
						(*i)->playCircle();
						playerOne = true;

						// Check to see if player 2 won
					}
					gameOver = checkForGameOver();
					
					break;
				}
			}
		}
	}
}

bool Game::checkForGameOver(){
	if (board[0]->xShape && board[1]->xShape && board[2]->xShape){
		std::cout << "Player 1 wins" << std::endl;
		return true;
	}
}

