#ifndef GAME_H
#define GAME_H

#include "Rect.h"
#include <vector>


struct Game {
	std::vector<Rect*> board;

	bool playerOne;

	bool gameOver;

	Game();

	void draw();

	void handle(float mx, float my);

	bool checkForGameOver();
};


#endif
