#include <iostream>
#include <cmath>

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif

#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<string.h>


using namespace std;

int Matrix[3][3];
int PlayersTurn;
int Results;
bool GameOver; 
int width = 300, height = 350;
string shape;
int position;

//This will initialize the game
void InitializeGame(){
	// First we begin with X	
	PlayersTurn = 1;
  
	//Begin with the matrix cleared
   	for(int i = 0; i <= 2; i++){
       		for(int j = 0; j <= 2; j++){
          		Matrix[i][j] = 0;
       		}
   	}
}



//-------------------------------------------------------
// A function to handle mouse clicks
// Called every time the mouse button goes up or down
// Arguments: 	
//	b    - mouse button that was clicked, left or right
//	s 	 - state, either mouse-up or mouse-down
//	x, y - coordinates of the mouse when click occured
//-------------------------------------------------------
void appMouseFunc(int b, int s, int x, int y){
	for (int position = 0; position <= 9; position++)
	cout << "Clicked on position " << position << ": " << shape << endl;

	if(GameOver == false && b == GLUT_LEFT_BUTTON && s == GLUT_DOWN){
		if(PlayersTurn == 1){
			if(Matrix[(y - 50) / 100][x / 100] == 0){
				Matrix[(y - 50) / 100][x / 100] = 1;
				PlayersTurn = 2;
			}
		}
		else{
		if(Matrix[(y - 50) / 100][x / 100] == 0){
			Matrix[(y - 50) / 100][x / 100] = 2;
			PlayersTurn = 1;
		}
		}
	}
}



//This writes the text
void DrawString (void * font, char *s, float x, float y){
	unsigned int i;
	glRasterPos2f(x, y);

	for (i = 0; i < strlen (s); i++)
	glutBitmapCharacter (font, s[i]);
}

//This creates the tic-tac-toe table
void DrawLines(){
	glBegin(GL_LINES);
	glColor3f(0, 0, 0);

	//The vertical lines
	glVertex2f(100, 50);
	glVertex2f(100, 340);

	glVertex2f(200, 340);
	glVertex2f(200, 50);

	//The horizontal lines
	glVertex2f(0, 150);
	glVertex2f(300, 150);

	glVertex2f(0, 250);
	glVertex2f(300, 250);
		glEnd();
}

//This draws XOs
void DrawXO(){
	for(int i = 0; i <= 2; i++){
		for(int j = 0; j <= 2; j++){
			if(Matrix[i][j] == 1){
				shape = "X";
				glBegin(GL_LINES);
				glVertex2f(50 + j * 100 - 25, 100 + i * 100 - 25);
				glVertex2f(50 + j * 100 + 25, 100 + i * 100 + 25);
				glVertex2f(50 + j * 100 - 25, 100 + i * 100 + 25);
				glVertex2f(50 + j * 100 + 25, 100 + i * 100 - 25);
					glEnd();
	}
	else if(Matrix[i][j] == 2){
		shape = "O";
		glBegin(GL_LINE_LOOP);
		glVertex2f(50 + j * 100 - 25, 100 + i * 100 - 25);
		glVertex2f(50 + j * 100 - 25, 100 + i * 100 + 25);
		glVertex2f(50 + j * 100 + 25, 100 + i * 100 + 25);
		glVertex2f(50 + j * 100 + 25, 100 + i * 100 - 25);
			glEnd();
	}
		}
	} 
}

//This checks for winner
bool CheckForWin(){
	int i, j;
  
	//checks horizontaly
	for(i = 0; i <= 2; i++){
		for(j = 1; j <= 2; j++){
			if(Matrix[i][0] != 0 && Matrix[i][0] == Matrix[i][j]){
				if(j == 2)
					return true;
			}
			 else
				break;
		}
	}
  
   //checks verticaly
	for(i = 0; i <= 2; i++){
		for(j = 1; j <= 2; j++){
			if(Matrix[0][i] != 0 && Matrix[0][i] == Matrix[j][i]){
				if(j == 2)
					return true;
			}
			 else
				break;
		}
	}
  
   //checks diagonaly
	for(i = 1; i <= 2; i++){
		if(Matrix[0][0] != 0 && Matrix[0][0] == Matrix[i][i]){
			if(i == 2)
				return true;
		}
		 else
			break;
	}
	for(i = 1; i <= 2; i++){
		if(Matrix[2][0] != 0 && Matrix[2][0] == Matrix[2 - i][i]){
			if(i == 2)
				return true;
		}
		 else
			break;
	}
}

//This checks for draw
bool CheckForDraw(){
	int i, j;
	bool Draw;
  
	for(i = 0; i <= 2; i++){
		for(j = 0; j <= 2; j++){
          		if(Matrix[i][j] == 0)
				return false;
		}
	}
	return true;  
}

//-------------------------------------------------------
// A function to draw the scene
//-------------------------------------------------------
void appDrawScene(){
	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(1, 1, 1, 1);
	glColor3f(0, 0, 0);

	if(PlayersTurn == 1)
		DrawString(GLUT_BITMAP_HELVETICA_18, "Player 1", 100, 30);  
	else
		DrawString(GLUT_BITMAP_HELVETICA_18, "Player 2", 100, 30);  
  
	DrawLines();
	DrawXO();
  
	if(CheckForWin() == true){
       		if(PlayersTurn == 1){
           		GameOver = true;
           		Results = 2; //player2 wins
		}
       		 else{
           		GameOver = true;
           		Results = 1; //player1 wins
       		}
   	}
   	 else if(CheckForDraw() == true){
       		GameOver = true;
       		Results = 0;
   	}
  
   	if(GameOver == true){
      		DrawString(GLUT_BITMAP_HELVETICA_18, "GAME OVER", 100, 160);
      
       		if(Results == 0)
           		DrawString(GLUT_BITMAP_HELVETICA_18, "Neither Player wins", 110, 185);
      
       		if(Results == 1)
           		DrawString(GLUT_BITMAP_HELVETICA_18, "Player 1 has won.", 95, 185);
      
       		if(Results == 2)
           		DrawString(GLUT_BITMAP_HELVETICA_18, "Player 2 has won", 95, 185);
      
   	}
  
   glutSwapBuffers();
}

//-------------------------------------------------------
// A function to handle window resizing
// Called every time the window is resized
// Arguments: 	
//	b    - mouse button that was clicked, left or right
//	s 	 - state, either mouse-up or mouse-down
//	x, y - coordinates of the mouse when click occured
//-------------------------------------------------------
void appReshapeFunc(int x, int y){
   	glViewport(0, 0, x, y);
   	glMatrixMode(GL_PROJECTION);
   	glLoadIdentity();
   	glOrtho(0, x, y, 0, 0, 1);
   	glMatrixMode(GL_MODELVIEW);
}


int main(int argc, char **argv){
	// Initialize GLUT
	InitializeGame();
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_RGB|GLUT_DOUBLE);

	// Setup window position, size, and title
	glutInitWindowPosition(100,100);
	glutInitWindowSize(width, height);
	glutCreateWindow("CSE165 Lab02");

	// Setup some OpenGL options
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);

	// Set callback for drawing the scene
	glutDisplayFunc(appDrawScene);
	
	// Set callback for resizing th window
	glutReshapeFunc(appReshapeFunc);

	// Set callback to handle mouse clicks
	glutMouseFunc(appMouseFunc);

	
	glutIdleFunc(appDrawScene);

	// Start the main loop
	glutMainLoop();


}











