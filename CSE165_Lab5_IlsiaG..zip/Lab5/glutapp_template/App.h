#ifndef App_h
#define App_h

#include "GlutApp.h"
#include "Rect.h"
#include "Players.h"
#include "Bullet.h"

class App: public GlutApp {

    Rect* rect;
    Players* players;
    Bullet* bullet;

public:
    
    App(int argc, char** argv, int width, int height, const char* title);
    
    void draw();
    
    void keyDown(unsigned char key, float x, float y);

    void keyUp(unsigned char key, float x, float y);

    bool goLeft, goRight;

    //void idle();

    ~App();
    
};

#endif
