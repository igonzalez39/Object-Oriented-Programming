#include <iostream>
#include "App.h"


App::App(int argc, char** argv, int width, int height, const char* title): GlutApp(argc, argv, width, height, title){
    rect = new Rect();
    players = new Players();
    bullet = new Bullet(); 
}

void App::draw() {
    rect->draw();
    players->draw();
    bullet -> draw();


}

void App::keyDown(unsigned char key, float x, float y){
    if (key == 27){
        exit(0);
    }
    if (key == 'a'){
        goLeft = true;
    }
    if (key == 'd'){
        goRight = true;
    }
}

void App::keyUp(unsigned char key, float x, float y){
    if (key == 'a'){
        goLeft = false;
    }
    if (key == 'd'){
        goRight = false;
    }

}



App::~App(){
    std::cout << "Exiting..." << std::endl;
    delete rect;
}

