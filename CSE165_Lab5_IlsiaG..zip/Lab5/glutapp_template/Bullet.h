#ifndef Bullet_H
#define Bullet_H

class Bullet{
    float x;
	float y;

	float red;
	float green; 
	float blue;

	float w;
	float h;

	int velocity;


public:
    Bullet();
    Bullet(float, float, float, float);
    Bullet(float, float, float, float, float, float, float);
    Bullet(const Bullet&);
    bool operator == (const Bullet&);

    ~Bullet();
    void draw();
    bool Constains(float, float) const;
    float getX() const ;
	float getY() const ;
	float getW() const ;
	float getH() const ;
	float getR() const ;
	float getG() const ;
	float getB() const ;
	void setX(float x);
	void setY(float y);
	void setW(float w);
	void setH(float h);

	void move();
	int get_velocity() const;

};

#endif