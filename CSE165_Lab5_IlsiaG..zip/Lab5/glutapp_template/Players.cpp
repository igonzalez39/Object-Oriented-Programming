#include "Players.h"
#include <math.h>

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif

Players::Players(){
    x = -0.1;
	y = -0.6;
	red = 1;
	green = 1;
	blue = 1;

	w = 0.2;
	h = 0.2;
    
}

Players::Players(float x, float y, float w, float h){
	this->x = x;
	this->y = y;

	red = 1;
	green = 1;
	blue = 1;

	this->w = w;
	this->h = h;
}

Players::Players(float x, float y, float w, float h, float red, float green, float blue){
	this->x = x;
	this->y = y;

	this->red = red;
	this->green = green;
	this->blue = blue;

	this->w = w;
	this->h = h;
}

Players::Players(const Players& other){
	x = other.x;
	y = other.y;

	red = other.red;
	green = other.green;
	blue = other.blue;

	w = other.w;
	h = other.h;
}

bool Players::operator== (const Players& other){
	return 	x == other.x && 
			y == other.y && 
			h == other.h && 
			red == other.red && 
			green == other.green && 
			blue == other.blue;
}

/*PLayers::~Players(){
	// There is nothing to do here for now...
}*/

bool Players::contains(float x, float y) const {
	return (x > this->x) && (x < this->x + this->w) && (y < this->y) && (y > this->y - this->h);
}


void Players::draw(){

	glColor3f(red, green, blue);
	
	glBegin(GL_LINES);

	glVertex2f(x, y);
	glVertex2f(x+w, y);

	glVertex2f(x+w, y);
	glVertex2f(x+w, y-h);
	
	glVertex2f(x+w, y-h);
	glVertex2f(x, y-h);
	
	glVertex2f(x, y-h);
	glVertex2f(x, y);

	glEnd();
	
}

float Players::getX() const {
	return x;
}

float Players::getY() const {
	return y;
}

float Players::getW() const {
	return w;
}

float Players::getH() const {
	return h;
}

float Players::getR() const {
	return red;
}

float Players::getG() const {
	return green;
}

float Players::getB() const {
	return blue;
}

void Players::setX(float x){
	this->x = x;
}

void Players::setY(float y){
	this->y = y;
}

void Players::setW(float w){
	this->w = w;
}

void Players::setH(float h){
	this->h = h;
}
